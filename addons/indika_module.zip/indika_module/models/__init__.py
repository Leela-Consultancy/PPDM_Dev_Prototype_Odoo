from . import indikamodule_userstable
from . import indikamodule_vendortable
from . import indikamodule_websitestable
from . import indikamodule_privacypolicytable
from . import indikamodule_cookiedatatable
from . import indikamodule_cookiecategorytable
from . import indikamodule_maintable
from . import indikamodule_mappingtable


